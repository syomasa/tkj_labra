/*
 * kuva.h
 *
 *  Created on: 6.11.2020
 *      Author: Mikko
 */

#ifndef KUVA_H_
#define KUVA_H_

#include <ti/mw/grlib/grlib.h>

extern const tImage arrowU;
extern const tImage arrowD;
extern const tImage arrowR;
extern const tImage arrowL;
extern const tImage gondola;

#endif /* KUVA_H_ */
